﻿/******************************************************************************
 * Student Management System.
 *
 * This program allows users to manage student records in a MySQL database. It offers
 * three main functionalities: 
 * 
 * 1. **Add a new student**: The user can add a new student to the database by providing
 *    details such as last name, first name, Net ID, and UTD ID. The student is assigned
 *    a default password and role of "Student".
 * 
 * 2. **Update student information**: The user can update the last name and/or first name
 *    of an existing student identified by their UTD ID.
 * 
 * 3. **Delete a student**: The user can remove a student's record from the database by 
 *    entering their UTD ID.
 * 
 * The program interacts with a MySQL database using the MySql.Data.MySqlClient namespace
 * and performs these actions using parameterized SQL queries to prevent SQL injection.
 * 
 * Written by Tahoor Khalid (txk210035) for Computer Science Project (CS4485),
 * starting November 16, 2024.
 * 
 * **Database Setup**:
 * The program assumes a MySQL database with a `users` table. The `users` table must contain 
 * the following columns: `utd_id`, `net_id`, `password`, `last_name`, `first_name`, and `user_role`.
 * 
 * **Program Flow**:
 * 1. The program first prompts the user to choose an operation: "Add", "Update", or "Delete".
 * 2. Based on the user's choice, the corresponding method is called:
 *    - **AddStudent**: Prompts for student details and adds a new record.
 *    - **UpdateStudent**: Prompts for the UTD ID of the student to update and modifies 
 *      the student's information.
 *    - **DeleteStudent**: Prompts for the UTD ID of the student to delete and removes 
 *      the student's record.
 * 
 * **Error Handling**:
 * The program includes error handling to ensure any issues with database connections or 
 * SQL queries are caught and reported to the user.
 * 
 * **Inputs**:
 * - Last Name: The student's last name.
 * - First Name: The student's first name.
 * - Net ID: The student's Net ID.
 * - UTD ID: The student's UTD ID.
 * 
 * **Outputs**:
 * - Success or error message displayed to the user based on the operation result.
 *
 *****************************************************************************/

using System;
using MySql.Data.MySqlClient;

class Program
{
    // Connection string for MySQL database
    static string connectionString = "Server=localhost;Database=my_database;Uid=root;Pwd=Tza3bros123$;";

    // Main entry point of the program
    static void Main(string[] args)
    {
        // Prompt user for operation choice (Add, Update, Delete)
        Console.WriteLine("Choose an operation: Add, Update, Delete");
        string operation = Console.ReadLine().ToLower(); // Convert input to lowercase for easy comparison

        // Switch based on user input
        switch (operation)
        {
            case "add":
                AddStudent(); // Call AddStudent method to add a student
                break;
            case "update":
                UpdateStudent(); // Call UpdateStudent method to update student information
                break;
            case "delete":
                DeleteStudent(); // Call DeleteStudent method to delete a student
                break;
            default:
                // If the input is invalid, show an error message
                Console.WriteLine("Invalid operation.");
                break;
        }
    }

    // Method to add a new student to the database
    static void AddStudent()
    {
        // Prompt the user for student details
        Console.WriteLine("Enter Last Name:");
        string lastName = Console.ReadLine(); // Get the last name

        Console.WriteLine("Enter First Name:");
        string firstName = Console.ReadLine(); // Get the first name

        Console.WriteLine("Enter Net ID:");
        string netID = Console.ReadLine(); // Get the Net ID

        Console.WriteLine("Enter UTD ID:");
        string utdID = Console.ReadLine(); // Get the UTD ID

        // Default user role is "Student"
        string userRole = "Student";

        // Create and open a MySQL connection
        using (MySqlConnection conn = new MySqlConnection(connectionString))
        {
            try
            {
                // SQL query to insert a new student record into the database
                string query = "INSERT INTO users (utd_id, net_id, password, last_name, first_name, user_role) " +
                               "VALUES (@UtdId, @NetId, 'default123', @LastName, @FirstName, @UserRole)";

                // Create the MySQL command object and add parameters
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@UtdId", utdID); // Set UTD ID
                cmd.Parameters.AddWithValue("@NetId", netID); // Set Net ID
                cmd.Parameters.AddWithValue("@LastName", lastName); // Set Last Name
                cmd.Parameters.AddWithValue("@FirstName", firstName); // Set First Name
                cmd.Parameters.AddWithValue("@UserRole", userRole); // Set User Role

                // Open the connection, execute the query, and close the connection
                conn.Open();
                int rowsAffected = cmd.ExecuteNonQuery(); // Execute the query
                conn.Close();

                // Output the number of rows affected (inserted)
                Console.WriteLine($"{rowsAffected} row(s) added successfully.");
            }
            catch (Exception ex)
            {
                // Handle any exceptions and display an error message
                Console.WriteLine("Error: " + ex.Message);
            }
        }
    }

    // Method to update an existing student's information
    static void UpdateStudent()
    {
        // Prompt the user for the UTD ID of the student to be updated
        Console.WriteLine("Enter UTD ID of Student to Update:");
        string utdID = Console.ReadLine(); // Get UTD ID

        // Prompt the user for new student details (Last Name and/or First Name)
        Console.WriteLine("Enter New Last Name (Leave blank to skip):");
        string newLastName = Console.ReadLine(); // Get new Last Name

        Console.WriteLine("Enter New First Name (Leave blank to skip):");
        string newFirstName = Console.ReadLine(); // Get new First Name

        // Create and open a MySQL connection
        using (MySqlConnection conn = new MySqlConnection(connectionString))
        {
            // Base query to update the student's information
            string query = "UPDATE users SET ";

            // Add conditions to update Last Name and/or First Name if provided
            if (!string.IsNullOrEmpty(newLastName)) query += "last_name = @NewLastName, ";
            if (!string.IsNullOrEmpty(newFirstName)) query += "first_name = @NewFirstName, ";

            // Remove trailing commas and add the WHERE clause
            query = query.TrimEnd(',', ' ') + " WHERE utd_id = @UTDID";

            // Create the MySQL command object and add parameters
            MySqlCommand cmd = new MySqlCommand(query, conn);
            if (!string.IsNullOrEmpty(newLastName)) cmd.Parameters.AddWithValue("@NewLastName", newLastName); // Set new Last Name
            if (!string.IsNullOrEmpty(newFirstName)) cmd.Parameters.AddWithValue("@NewFirstName", newFirstName); // Set new First Name
            cmd.Parameters.AddWithValue("@UTDID", utdID); // Set UTD ID

            // Open the connection, execute the query, and close the connection
            conn.Open();
            cmd.ExecuteNonQuery(); // Execute the update query
            conn.Close();

            // Inform the user that the student has been updated successfully
            Console.WriteLine("Student updated successfully!");
        }
    }

    // Method to delete an existing student from the database
    static void DeleteStudent()
    {
        // Prompt the user for the UTD ID of the student to be deleted
        Console.WriteLine("Enter UTD ID of Student to Delete:");
        string utdID = Console.ReadLine(); // Get UTD ID

        // Create and open a MySQL connection
        using (MySqlConnection conn = new MySqlConnection(connectionString))
        {
            // SQL query to delete a student record based on the provided UTD ID
            string query = "DELETE FROM users WHERE utd_id = @UTDID";

            // Create the MySQL command object and add parameter
            MySqlCommand cmd = new MySqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@UTDID", utdID); // Set UTD ID

            // Open the connection, execute the query, and close the connection
            conn.Open();
            cmd.ExecuteNonQuery(); // Execute the delete query
            conn.Close();

            // Inform the user that the student has been deleted successfully
            Console.WriteLine("Student deleted successfully!");
        }
    }
}


